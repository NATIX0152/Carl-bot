const {
  SlashCommandBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle,
  ComponentType, MessageFlags,
} = require('discord.js');
const { emo } = require('../utils/emojis');

const data = new SlashCommandBuilder()
  .setName('autorole')
  .setDescription('Donner le même rôle à tous les membres du serveur')
  .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
  .setContexts(0)
  .addRoleOption((o) => o.setName('role').setDescription('Rôle à donner à tout le monde').setRequired(true))
  .addBooleanOption((o) => o.setName('bots').setDescription('Donner aussi le rôle aux bots (défaut : non)'));

async function execute(interaction) {
  const { guild } = interaction;
  const role = interaction.options.getRole('role');
  const withBots = interaction.options.getBoolean('bots') ?? false;
  const err = (c) => interaction.reply({ content: `${emo('error')} ${c}`, flags: MessageFlags.Ephemeral });

  const me = guild.members.me;
  const isOwner = guild.ownerId === interaction.user.id;
  if (role.id === guild.id) return err('Impossible d\'utiliser @everyone.');
  if (role.managed) return err('Ce rôle est géré par un bot / une intégration, je ne peux pas le donner.');
  if (role.position >= me.roles.highest.position) return err('Ce rôle est au-dessus (ou égal) à mon rôle : monte mon rôle dans la liste des rôles.');
  if (!isOwner && role.position >= interaction.member.roles.highest.position) return err('Ce rôle est au-dessus (ou égal) à ton rôle le plus haut.');
  if (!isOwner && role.permissions.has(PermissionFlagsBits.Administrator)) {
    return err('Par sécurité, seul le propriétaire du serveur peut donner à tous un rôle Administrateur.');
  }

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });
  const members = await guild.members.fetch();
  const targets = members.filter((m) => (withBots || !m.user.bot) && !m.roles.cache.has(role.id));
  if (!targets.size) {
    return interaction.editReply(`${emo('success')} Tout le monde a déjà le rôle <@&${role.id}>.`);
  }

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('autorole_yes').setLabel(`Oui, donner à ${targets.size} membres`).setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('autorole_no').setLabel('Annuler').setStyle(ButtonStyle.Secondary),
  );
  const msg = await interaction.editReply({
    content: `${emo('warn')} Donner <@&${role.id}> à **${targets.size}** membre(s)${withBots ? ' (bots inclus)' : ''} ? Confirme dans les 30 secondes.`,
    components: [row],
    allowedMentions: { parse: [] },
  });

  let click;
  try {
    click = await msg.awaitMessageComponent({
      componentType: ComponentType.Button,
      filter: (i) => i.user.id === interaction.user.id,
      time: 30_000,
    });
  } catch {
    return interaction.editReply({ content: '⏱️ Temps écoulé, rien n\'a été fait.', components: [] });
  }
  if (click.customId !== 'autorole_yes') {
    return click.update({ content: `${emo('success')} Annulé.`, components: [] });
  }

  await click.update({ content: `${emo('loading')} Attribution en cours à ${targets.size} membres... (peut prendre du temps)`, components: [] });
  let ok = 0;
  let ko = 0;
  for (const member of targets.values()) {
    try {
      await member.roles.add(role, `/autorole par ${interaction.user.tag}`);
      ok++;
    } catch {
      ko++;
    }
  }
  const done = `${emo('success')} Terminé : <@&${role.id}> donné à **${ok}** membre(s)${ko ? `, **${ko}** échec(s)` : ''}.`;
  // Si l'interaction a expiré (>15 min), on prévient dans le salon
  await interaction.editReply({ content: done, allowedMentions: { parse: [] } })
    .catch(() => interaction.channel?.send({ content: `<@${interaction.user.id}> ${done}`, allowedMentions: { users: [interaction.user.id], roles: [] } }).catch(() => {}));
}

module.exports = { data, execute };
