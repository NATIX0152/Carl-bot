const {
  SlashCommandBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle,
  ComponentType, MessageFlags,
} = require('discord.js');

const data = new SlashCommandBuilder()
  .setName('suproleall')
  .setDescription('⚠️ Supprimer TOUS les rôles du serveur (irréversible)')
  .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
  .setContexts(0);

async function execute(interaction) {
  const { guild } = interaction;
  const me = guild.members.me;
  const isOwner = guild.ownerId === interaction.user.id;
  const limit = isOwner
    ? me.roles.highest.position
    : Math.min(me.roles.highest.position, interaction.member.roles.highest.position);

  // @everyone, rôles de bots/intégrations et rôles au-dessus de nous ne peuvent pas / ne doivent pas être supprimés
  const roles = guild.roles.cache
    .filter((r) => r.id !== guild.id && !r.managed && r.position < limit)
    .sort((a, b) => b.position - a.position);

  if (!roles.size) {
    return interaction.reply({ content: '❌ Aucun rôle supprimable (ils sont au-dessus de mon rôle / du tien, ou gérés par un bot).', flags: MessageFlags.Ephemeral });
  }

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('supall_yes').setLabel(`Oui, supprimer ${roles.size} rôles`).setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('supall_no').setLabel('Annuler').setStyle(ButtonStyle.Secondary),
  );
  await interaction.reply({
    content: `⚠️ **Tu es sur le point de supprimer ${roles.size} rôles. C'est IRRÉVERSIBLE** (les membres perdent tous ces rôles, y compris les rôles « Vouch »).\nConfirme dans les 30 secondes.`,
    components: [row],
    flags: MessageFlags.Ephemeral,
  });
  const msg = await interaction.fetchReply();

  let click;
  try {
    click = await msg.awaitMessageComponent({
      componentType: ComponentType.Button,
      filter: (i) => i.user.id === interaction.user.id,
      time: 30_000,
    });
  } catch {
    return interaction.editReply({ content: '⏱️ Temps écoulé, rien n\'a été supprimé.', components: [] });
  }
  if (click.customId !== 'supall_yes') {
    return click.update({ content: '✅ Annulé, rien n\'a été supprimé.', components: [] });
  }

  await click.update({ content: `⏳ Suppression de ${roles.size} rôles en cours...`, components: [] });
  let ok = 0;
  let ko = 0;
  for (const role of roles.values()) {
    try {
      await role.delete(`/suproleall par ${interaction.user.tag}`);
      ok++;
    } catch {
      ko++;
    }
  }
  await interaction.editReply({ content: `🗑️ Terminé : **${ok}** rôle(s) supprimé(s)${ko ? `, **${ko}** échec(s)` : ''}.` });
}

module.exports = { data, execute };
