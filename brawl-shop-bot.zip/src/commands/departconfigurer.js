const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, MessageFlags } = require('discord.js');
const db = require('../db');
const { emo } = require('../utils/emojis');
const { build, readOptions, VARS } = require('../utils/welcome');

const data = new SlashCommandBuilder()
  .setName('departconfigurer')
  .setDescription('Configurer le système de départ (embed d\'au revoir)')
  .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
  .setContexts(0)
  .addChannelOption((o) => o.setName('salon').setDescription('Salon des départs').addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement))
  .addStringOption((o) => o.setName('titre').setDescription('Titre de l\'embed (variables : {username} {server} {count}...)').setMaxLength(200))
  .addStringOption((o) => o.setName('message').setDescription('Description (variables : {username} {server} {count} {joined}) \\n = saut de ligne').setMaxLength(1500))
  .addStringOption((o) => o.setName('couleur').setDescription('Couleur hexadécimale, ex : #ED4245').setMaxLength(7))
  .addStringOption((o) => o.setName('image').setDescription('Lien https d\'une grande image/bannière (ou « aucune »)').setMaxLength(500))
  .addBooleanOption((o) => o.setName('tester').setDescription('Voir un aperçu (avec toi comme membre parti)'))
  .addBooleanOption((o) => o.setName('desactiver').setDescription('Désactiver le système de départ'));

async function execute(interaction) {
  const err = (c) => interaction.reply({ content: `${emo('error')} ${c}`, flags: MessageFlags.Ephemeral });
  const o = interaction.options;
  const g = db.guild(interaction.guildId);

  if (o.getBoolean('desactiver')) {
    delete g.leave;
    db.save();
    return interaction.reply({ content: `${emo('success')} Système de départ désactivé.`, flags: MessageFlags.Ephemeral });
  }

  const channel = o.getChannel('salon');
  if (!channel && !g.leave) return err('Indique un `salon` pour la première configuration.');
  const { error, patch } = readOptions(o);
  if (error) return err(error);

  g.leave = { ...g.leave, ...patch, channelId: channel?.id ?? g.leave.channelId };
  if (g.leave.image === null) delete g.leave.image;
  db.save();

  if (o.getBoolean('tester')) {
    const preview = build('leave', g.leave, interaction.member);
    return interaction.reply({ content: 'Aperçu du message de départ :', embeds: preview.embeds, flags: MessageFlags.Ephemeral });
  }
  await interaction.reply({
    content: `${emo('success')} Départs configurés dans <#${g.leave.channelId}>.\n• Variables : ${VARS}\nAjoute \`tester: True\` pour voir l'aperçu.`,
    flags: MessageFlags.Ephemeral,
    allowedMentions: { parse: [] },
  });
}

module.exports = { data, execute };
