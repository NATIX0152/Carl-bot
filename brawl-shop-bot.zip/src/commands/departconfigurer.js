const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, MessageFlags } = require('discord.js');
const db = require('../db');
const { emo } = require('../utils/emojis');
const { build, readOptions, applyBanner, VARS } = require('../utils/welcome');
const { hasBanner, removeBanner } = require('../utils/card');

const data = new SlashCommandBuilder()
  .setName('departconfigurer')
  .setDescription('Configurer le système de départ (message, bannière)')
  .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
  .setContexts(0)
  .addChannelOption((o) => o.setName('salon').setDescription('Salon des départs').addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement))
  .addStringOption((o) => o.setName('message').setDescription('Ton message (variables : {username} {server} {count} {joined}) \\n = saut de ligne').setMaxLength(1500))
  .addStringOption((o) => o.setName('titre').setDescription('Titre de l\'embed (variables : {username} {server} {count})').setMaxLength(200))
  .addAttachmentOption((o) => o.setName('banniere').setDescription('Image envoyée en fond de la carte de départ'))
  .addStringOption((o) => o.setName('banniere_lien').setDescription('OU un lien https d\'image pour la bannière').setMaxLength(500))
  .addStringOption((o) => o.setName('couleur').setDescription('Couleur de l\'embed, ex : #ED4245').setMaxLength(7))
  .addBooleanOption((o) => o.setName('retirer_banniere').setDescription('Retirer la bannière'))
  .addBooleanOption((o) => o.setName('tester').setDescription('Voir un aperçu (avec toi comme membre parti)'))
  .addBooleanOption((o) => o.setName('desactiver').setDescription('Désactiver tout le système de départ'));

async function execute(interaction) {
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });
  const err = (c) => interaction.editReply(`${emo('error')} ${c}`);
  const o = interaction.options;
  const gid = interaction.guildId;
  const g = db.guild(gid);

  if (o.getBoolean('desactiver')) {
    delete g.leave;
    removeBanner(gid, 'leave');
    db.save();
    return interaction.editReply(`${emo('success')} Système de départ désactivé.`);
  }

  const channel = o.getChannel('salon');
  if (!channel && !g.leave) return err('Indique un `salon` pour la première configuration.');
  const { error, patch } = readOptions(o);
  if (error) return err(error);
  const bannerError = await applyBanner(o, gid, 'leave');
  if (bannerError) return err(bannerError);

  g.leave = { ...g.leave, ...patch, channelId: channel?.id ?? g.leave.channelId };
  db.save();

  if (o.getBoolean('tester')) {
    const preview = await build('leave', g.leave, interaction.member);
    return interaction.editReply({ content: 'Aperçu du message de départ :', embeds: preview.embeds, files: preview.files });
  }
  await interaction.editReply({
    content:
      `${emo('success')} Départs configurés dans <#${g.leave.channelId}>.\n` +
      `• Bannière : ${hasBanner(gid, 'leave') ? 'oui' : 'non'}\n• Variables : ${VARS}\nAjoute \`tester: True\` pour voir l'aperçu.`,
    allowedMentions: { parse: [] },
  });
}

module.exports = { data, execute };
