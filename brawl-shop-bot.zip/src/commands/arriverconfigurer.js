const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, MessageFlags } = require('discord.js');
const db = require('../db');
const { emo } = require('../utils/emojis');
const { build, readOptions, VARS } = require('../utils/welcome');

const data = new SlashCommandBuilder()
  .setName('arriverconfigurer')
  .setDescription('Configurer le système d\'arrivée (embed de bienvenue)')
  .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
  .setContexts(0)
  .addChannelOption((o) => o.setName('salon').setDescription('Salon des arrivées').addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement))
  .addStringOption((o) => o.setName('titre').setDescription('Titre de l\'embed (variables : {username} {server} {count}...)').setMaxLength(200))
  .addStringOption((o) => o.setName('message').setDescription('Description (variables : {user} {username} {server} {count} {created}) \\n = saut de ligne').setMaxLength(1500))
  .addStringOption((o) => o.setName('couleur').setDescription('Couleur hexadécimale, ex : #57F287').setMaxLength(7))
  .addStringOption((o) => o.setName('image').setDescription('Lien https d\'une grande image/bannière (ou « aucune »)').setMaxLength(500))
  .addRoleOption((o) => o.setName('role').setDescription('Rôle donné automatiquement aux nouveaux membres'))
  .addBooleanOption((o) => o.setName('mp').setDescription('Envoyer aussi le message en MP au nouveau membre'))
  .addBooleanOption((o) => o.setName('tester').setDescription('Voir un aperçu (avec toi comme nouveau membre)'))
  .addBooleanOption((o) => o.setName('desactiver').setDescription('Désactiver le système d\'arrivée'));

async function execute(interaction) {
  const err = (c) => interaction.reply({ content: `${emo('error')} ${c}`, flags: MessageFlags.Ephemeral });
  const o = interaction.options;
  const g = db.guild(interaction.guildId);

  if (o.getBoolean('desactiver')) {
    delete g.welcome;
    db.save();
    return interaction.reply({ content: `${emo('success')} Système d'arrivée désactivé.`, flags: MessageFlags.Ephemeral });
  }

  const channel = o.getChannel('salon');
  if (!channel && !g.welcome) return err('Indique un `salon` pour la première configuration.');
  const { error, patch } = readOptions(o);
  if (error) return err(error);

  g.welcome = { ...g.welcome, ...patch, channelId: channel?.id ?? g.welcome.channelId };
  if (g.welcome.image === null) delete g.welcome.image;
  const role = o.getRole('role');
  if (role) g.welcome.roleId = role.id;
  const mp = o.getBoolean('mp');
  if (mp !== null) g.welcome.dm = mp;
  db.save();

  if (o.getBoolean('tester')) {
    const preview = build('welcome', g.welcome, interaction.member);
    return interaction.reply({ content: 'Aperçu du message d\'arrivée :', embeds: preview.embeds, flags: MessageFlags.Ephemeral });
  }
  const w = g.welcome;
  await interaction.reply({
    content:
      `${emo('success')} Arrivées configurées dans <#${w.channelId}>.\n` +
      `• Rôle auto : ${w.roleId ? `<@&${w.roleId}>` : 'aucun'}\n• MP au membre : ${w.dm ? 'oui' : 'non'}\n` +
      `• Variables : ${VARS}\nAjoute \`tester: True\` pour voir l'aperçu.`,
    flags: MessageFlags.Ephemeral,
    allowedMentions: { parse: [] },
  });
}

module.exports = { data, execute };
