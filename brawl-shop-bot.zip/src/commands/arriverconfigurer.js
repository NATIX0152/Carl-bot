const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, MessageFlags } = require('discord.js');
const db = require('../db');
const { emo } = require('../utils/emojis');
const { build, readOptions, applyBanner, VARS } = require('../utils/welcome');
const { hasBanner, removeBanner } = require('../utils/card');

const data = new SlashCommandBuilder()
  .setName('arriverconfigurer')
  .setDescription('Configurer le système d\'arrivée (message, auto-rôle, bannière)')
  .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
  .setContexts(0)
  .addChannelOption((o) => o.setName('salon').setDescription('Salon des arrivées').addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement))
  .addStringOption((o) => o.setName('message').setDescription('Ton message (variables : {user} {username} {server} {count} {created}) \\n = saut de ligne').setMaxLength(1500))
  .addStringOption((o) => o.setName('titre').setDescription('Titre de l\'embed (variables : {username} {server} {count})').setMaxLength(200))
  .addRoleOption((o) => o.setName('role').setDescription('Auto-rôle donné à chaque nouveau membre'))
  .addAttachmentOption((o) => o.setName('banniere').setDescription('Image envoyée en fond de la carte d\'arrivée'))
  .addStringOption((o) => o.setName('banniere_lien').setDescription('OU un lien https d\'image pour la bannière').setMaxLength(500))
  .addStringOption((o) => o.setName('couleur').setDescription('Couleur de l\'embed, ex : #57F287').setMaxLength(7))
  .addBooleanOption((o) => o.setName('mp').setDescription('Envoyer aussi le message en MP au nouveau membre'))
  .addBooleanOption((o) => o.setName('retirer_role').setDescription('Retirer l\'auto-rôle'))
  .addBooleanOption((o) => o.setName('retirer_banniere').setDescription('Retirer la bannière'))
  .addBooleanOption((o) => o.setName('tester').setDescription('Voir un aperçu (avec toi comme nouveau membre)'))
  .addBooleanOption((o) => o.setName('desactiver').setDescription('Désactiver tout le système d\'arrivée'));

async function execute(interaction) {
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });
  const err = (c) => interaction.editReply(`${emo('error')} ${c}`);
  const o = interaction.options;
  const gid = interaction.guildId;
  const g = db.guild(gid);

  if (o.getBoolean('desactiver')) {
    delete g.welcome;
    removeBanner(gid, 'welcome');
    db.save();
    return interaction.editReply(`${emo('success')} Système d'arrivée désactivé.`);
  }

  const channel = o.getChannel('salon');
  if (!channel && !g.welcome) return err('Indique un `salon` pour la première configuration.');
  const { error, patch } = readOptions(o);
  if (error) return err(error);
  const bannerError = await applyBanner(o, gid, 'welcome');
  if (bannerError) return err(bannerError);

  g.welcome = { ...g.welcome, ...patch, channelId: channel?.id ?? g.welcome.channelId };
  const role = o.getRole('role');
  if (role) g.welcome.roleId = role.id;
  if (o.getBoolean('retirer_role')) delete g.welcome.roleId;
  const mp = o.getBoolean('mp');
  if (mp !== null) g.welcome.dm = mp;
  db.save();

  if (o.getBoolean('tester')) {
    const preview = await build('welcome', g.welcome, interaction.member);
    return interaction.editReply({ content: 'Aperçu du message d\'arrivée :', embeds: preview.embeds, files: preview.files });
  }
  const w = g.welcome;
  await interaction.editReply({
    content:
      `${emo('success')} Arrivées configurées dans <#${w.channelId}>.\n` +
      `• Auto-rôle : ${w.roleId ? `<@&${w.roleId}>` : 'aucun'}\n` +
      `• Bannière : ${hasBanner(gid, 'welcome') ? 'oui' : 'non'}\n• MP au membre : ${w.dm ? 'oui' : 'non'}\n` +
      `• Variables : ${VARS}\nAjoute \`tester: True\` pour voir l'aperçu.`,
    allowedMentions: { parse: [] },
  });
}

module.exports = { data, execute };
