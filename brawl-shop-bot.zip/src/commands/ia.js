const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const { askAI } = require('../utils/ai');

const data = new SlashCommandBuilder()
  .setName('ia')
  .setDescription('Poser une question sur nos services Brawl Stars (boost ranked, prestige...)')
  .addStringOption((o) => o.setName('question').setDescription('Ta question').setRequired(true).setMaxLength(500));

async function execute(interaction) {
  await interaction.deferReply();
  const r = await askAI(interaction.user.id, interaction.options.getString('question'));
  if (r.error) return interaction.editReply({ content: r.error });
  await interaction.editReply({ content: r.text, allowedMentions: { parse: [] } });
}

module.exports = { data, execute };
