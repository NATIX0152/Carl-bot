const path = require('path');
const {
  SlashCommandBuilder, PermissionFlagsBits, ChannelType, EmbedBuilder, AttachmentBuilder, MessageFlags,
} = require('discord.js');

// ✏️ MODIFIE ICI tes services (texte, couleurs). Les images sont dans le dossier /assets.
const SERVICES = [
  { file: 'bronze.png',    color: 0xcd7f32, title: 'Boost Ranked — Bronze',     text: 'Montée en rang jusqu\'au Bronze et au-delà.' },
  { file: 'argent.png',    color: 0xaab7d4, title: 'Boost Ranked — Argent',     text: 'Montée en rang vers l\'Argent.' },
  { file: 'or.png',        color: 0xf5c518, title: 'Boost Ranked — Or',         text: 'Montée en rang vers l\'Or.' },
  { file: 'diamant.png',   color: 0x3fc1ff, title: 'Boost Ranked — Diamant',    text: 'Montée en rang vers le Diamant.' },
  { file: 'mythique.png',  color: 0xb43cf0, title: 'Boost Ranked — Mythique',   text: 'Montée en rang vers le Mythique.' },
  { file: 'legendaire.png', color: 0xe8362d, title: 'Boost Ranked — Légendaire', text: 'Montée en rang vers le Légendaire.' },
  { file: 'masters.png',   color: 0xff9d00, title: 'Boost Ranked — Masters',    text: 'Le plus haut rang : Masters.' },
  { file: 'brawlpass.png', color: 0xffd400, title: 'Brawl Pass',                text: 'Progression du Brawl Pass.' },
];

const data = new SlashCommandBuilder()
  .setName('services')
  .setDescription('Envoyer le catalogue des services (ranked, Brawl Pass...)')
  .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
  .setContexts(0)
  .addChannelOption((o) => o.setName('salon').setDescription('Salon cible (défaut : ici)').addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement));

async function execute(interaction) {
  const channel = interaction.options.getChannel('salon') ?? interaction.channel;
  const files = SERVICES.map((s) => new AttachmentBuilder(path.join(__dirname, '..', '..', 'assets', s.file), { name: s.file }));
  const embeds = SERVICES.map((s) =>
    new EmbedBuilder()
      .setColor(s.color)
      .setTitle(s.title)
      .setDescription(`${s.text}\n🎫 Ouvre un ticket pour le prix et commander.`)
      .setThumbnail(`attachment://${s.file}`),
  );
  try {
    await channel.send({ embeds, files });
  } catch {
    return interaction.reply({ content: '❌ Je ne peux pas écrire / envoyer des fichiers dans ce salon.', flags: MessageFlags.Ephemeral });
  }
  await interaction.reply({ content: '✅ Catalogue envoyé.', flags: MessageFlags.Ephemeral });
}

module.exports = { data, execute };
