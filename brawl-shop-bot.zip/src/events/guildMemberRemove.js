const { Events } = require('discord.js');
const db = require('../db');
const { build } = require('../utils/welcome');

module.exports = {
  name: Events.GuildMemberRemove,
  async execute(client, member) {
    const cfg = db.data.guilds[member.guild.id]?.leave;
    if (!cfg || member.user.bot) return;
    await member.guild.channels.cache.get(cfg.channelId)?.send(await build('leave', cfg, member)).catch((e) => console.error('[départ] envoi', e.message));
  },
};
