const { Events } = require('discord.js');

// Les commandes ne sont enregistrées qu'à UN seul endroit (global OU serveur)
// et l'autre endroit est vidé, pour éviter de voir les commandes en double.
module.exports = {
  name: Events.ClientReady,
  once: true,
  async execute(client) {
    const body = client.commands.map((c) => c.data.toJSON());
    if (process.env.GUILD_ID) {
      await client.guilds.cache.get(process.env.GUILD_ID)?.commands.set(body);
      await client.application.commands.set([]); // vide les commandes globales
      console.log(`✅ ${body.length} commandes enregistrées sur le serveur ${process.env.GUILD_ID}`);
    } else {
      await client.application.commands.set(body);
      for (const guild of client.guilds.cache.values()) await guild.commands.set([]).catch(() => {}); // vide les commandes de serveur
      console.log(`✅ ${body.length} commandes globales enregistrées`);
    }
    console.log(`🤖 Connecté en tant que ${client.user.tag}`);
  },
};
