const { Events, EmbedBuilder } = require('discord.js');
const db = require('../db');
const { updateVouchRole, TRANCHE } = require('../utils/vouch');
const { parseTopic } = require('../utils/tickets');
const { askAI } = require('../utils/ai');

const COOLDOWN_MS = (Number(process.env.VOUCH_COOLDOWN_HOURS) || 24) * 3600 * 1000;

module.exports = {
  name: Events.MessageCreate,
  async execute(client, message) {
    if (message.author.bot || !message.guild) return;

    // IA : répond si on ping le bot, si on dit "Carl bot", ou dans son propre ticket (AI_TICKETS=false pour couper)
    if (!/^\+vouch\s/i.test(message.content)) {
      const pinged = message.mentions.users.has(client.user.id);
      const named = /\bcarl[\s-]?bot\b/i.test(message.content);
      const ticket = parseTopic(message.channel);
      const inOwnTicket = ticket && process.env.AI_TICKETS !== 'false' && message.author.id === ticket.ownerId;
      if (pinged || named || inOwnTicket) {
        const question = message.content
          .replace(new RegExp(`<@!?${client.user.id}>`, 'g'), '')
          .replace(/\bcarl[\s-]?bot\b/gi, '')
          .replace(/^[\s,:;!?.-]+/, '')
          .trim();
        if (!question) return message.reply({ content: '👋 Salut ! Pose-moi ta question sur nos services Brawl Stars (boost ranked, prestige...).', allowedMentions: { repliedUser: false } });
        await message.channel.sendTyping().catch(() => {});
        const r = await askAI(message.author.id, question);
        const out = r.text ?? r.error;
        return message.reply({ content: out, allowedMentions: { repliedUser: false, parse: [] } });
      }
    }

    const m = message.content.match(/^\+vouch\s+<@!?(\d+)>\s*([\s\S]*)$/i);
    if (!m) return;

    const reply = (text) => message.reply({ content: text, allowedMentions: { repliedUser: false, parse: [] } });
    const target = await message.guild.members.fetch(m[1]).catch(() => null);
    if (!target) return reply('❌ Membre introuvable.');
    if (target.user.bot) return reply('❌ Tu ne peux pas vouch un bot.');
    if (target.id === message.author.id) return reply('❌ Tu ne peux pas te vouch toi-même.');

    const key = `${message.guild.id}:${message.author.id}:${target.id}`;
    const last = db.data.vouchLog[key] ?? 0;
    if (Date.now() - last < COOLDOWN_MS) {
      return reply(`⏳ Tu as déjà vouch ce membre récemment (1 vouch / ${COOLDOWN_MS / 3600000}h par personne).`);
    }
    db.data.vouchLog[key] = Date.now();

    const counts = (db.data.vouches[message.guild.id] ??= {});
    const count = (counts[target.id] = (counts[target.id] ?? 0) + 1);
    db.save();

    let roleLine = '';
    try {
      const role = await updateVouchRole(target, count);
      if (role && count % TRANCHE === 0) roleLine = `\n🏅 Nouveau palier ! <@${target.id}> reçoit le rôle **${role.name}**.`;
    } catch (e) {
      console.error('[vouch] rôle', e.message);
      roleLine = '\n⚠️ Je n\'ai pas pu donner le rôle (permission « Gérer les rôles » / hiérarchie).';
    }

    const embed = new EmbedBuilder()
      .setColor(0x57f287)
      .setTitle('✅ Vouch enregistré')
      .setDescription(
        `<@${message.author.id}> a vouch <@${target.id}>${m[2].trim() ? `\n> ${m[2].trim().slice(0, 300)}` : ''}\n\n` +
        `📊 **${count}** vouch${count > 1 ? 's' : ''} au total${roleLine}`,
      )
      .setTimestamp();
    await message.reply({ embeds: [embed], allowedMentions: { repliedUser: false, parse: [] } });
  },
};
