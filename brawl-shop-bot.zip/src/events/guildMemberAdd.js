const { Events } = require('discord.js');
const db = require('../db');
const { build } = require('../utils/welcome');

module.exports = {
  name: Events.GuildMemberAdd,
  async execute(client, member) {
    const cfg = db.data.guilds[member.guild.id]?.welcome;
    if (!cfg) return;
    if (cfg.roleId) await member.roles.add(cfg.roleId, 'Rôle d\'arrivée').catch((e) => console.error('[arrivée] rôle', e.message));
    const msg = build('welcome', cfg, member);
    await member.guild.channels.cache.get(cfg.channelId)?.send(msg).catch((e) => console.error('[arrivée] envoi', e.message));
    if (cfg.dm) await member.send({ embeds: msg.embeds }).catch(() => {}); // MP fermés : on ignore
  },
};
