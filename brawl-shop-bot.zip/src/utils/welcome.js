const { EmbedBuilder, AttachmentBuilder } = require('discord.js');
const { renderCard, hasBanner, saveBanner, removeBanner } = require('./card');

const DEFAULTS = {
  welcome: {
    title: 'Bienvenue {username} ! 🎉',
    message: 'Bienvenue {user} sur **{server}** !\nTu es le membre n°**{count}**.\nCompte créé {created}.',
    color: 0x57f287,
  },
  leave: {
    title: '{username} nous a quittés',
    message: '**{username}** a quitté **{server}** 👋\nIl reste **{count}** membres.\nIl était là depuis {joined}.',
    color: 0xed4245,
  },
};

// Variables : {user} {username} {server} {count} {created} {joined}
function fill(tpl, member) {
  const ts = (ms) => (ms ? `<t:${Math.floor(ms / 1000)}:R>` : 'un moment');
  return tpl
    .replaceAll('{user}', `<@${member.id}>`)
    .replaceAll('{username}', member.user.username)
    .replaceAll('{server}', member.guild.name)
    .replaceAll('{count}', String(member.guild.memberCount))
    .replaceAll('{created}', ts(member.user.createdTimestamp))
    .replaceAll('{joined}', ts(member.joinedTimestamp));
}

// type : 'welcome' | 'leave'
// Si une bannière est configurée, une carte (bannière en fond + avatar + texte) est générée.
async function build(type, cfg, member) {
  const d = DEFAULTS[type];
  const count = member.guild.memberCount;
  const embed = new EmbedBuilder()
    .setColor(cfg.color ?? d.color)
    .setTitle(fill(cfg.title ?? d.title, member).slice(0, 256))
    .setDescription(fill(cfg.message ?? d.message, member).slice(0, 4000))
    .setFooter({
      text: type === 'welcome' ? `Membre n°${count}` : `${count} membres restants`,
      iconURL: member.guild.iconURL() ?? undefined,
    })
    .setTimestamp();

  const files = [];
  if (hasBanner(member.guild.id, type)) {
    try {
      const name = type === 'welcome' ? 'arrivee.png' : 'depart.png';
      files.push(new AttachmentBuilder(await renderCard(type, member), { name }));
      embed.setImage(`attachment://${name}`);
    } catch (e) {
      console.error('[card]', e.message);
      embed.setThumbnail(member.user.displayAvatarURL({ size: 256 }));
    }
  } else {
    embed.setThumbnail(member.user.displayAvatarURL({ size: 256 }));
  }
  return {
    content: type === 'welcome' ? `<@${member.id}>` : undefined,
    embeds: [embed],
    files,
    allowedMentions: { users: type === 'welcome' ? [member.id] : [] },
  };
}

// Lit les options communes /arriverconfigurer et /departconfigurer.
// Renvoie { error } ou { patch } (uniquement les champs fournis).
function readOptions(options) {
  const patch = {};
  const titre = options.getString('titre');
  if (titre) patch.title = titre.replaceAll('\\n', '\n');
  const message = options.getString('message');
  if (message) patch.message = message.replaceAll('\\n', '\n');
  const couleur = options.getString('couleur');
  if (couleur) {
    if (!/^#?[0-9a-f]{6}$/i.test(couleur)) return { error: 'Couleur invalide (ex : #5865F2).' };
    patch.color = parseInt(couleur.replace('#', ''), 16);
  }
  return { patch };
}

// Gère les options de bannière : banniere (fichier), banniere_lien (https), retirer_banniere.
// Renvoie un message d'erreur ou null.
async function applyBanner(options, guildId, type) {
  if (options.getBoolean('retirer_banniere')) {
    removeBanner(guildId, type);
    return null;
  }
  const file = options.getAttachment('banniere');
  const lien = options.getString('banniere_lien');
  const url = file?.url ?? lien;
  if (!url) return null;
  if (file && !(file.contentType ?? '').startsWith('image/')) return 'Le fichier `banniere` doit être une image.';
  try {
    await saveBanner(guildId, type, url);
  } catch (e) {
    return `Bannière refusée : ${e.message}`;
  }
  return null;
}

const VARS = '`{user}` `{username}` `{server}` `{count}` `{created}` `{joined}`';

module.exports = { build, fill, readOptions, applyBanner, VARS };
