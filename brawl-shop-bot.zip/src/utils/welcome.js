const { EmbedBuilder } = require('discord.js');

const DEFAULTS = {
  welcome: {
    title: 'Bienvenue {username} ! 🎉',
    message: 'Bienvenue {user} sur **{server}** !\nTu es le membre n°**{count}**.\nCompte créé {created}.',
    color: 0x57f287,
  },
  leave: {
    title: '{username} nous a quittés',
    message: '**{username}** a quitté **{server}** 👋\nIl reste **{count}** membres.\nIl était là depuis {joined}.',
    color: 0xed4245,
  },
};

// Variables : {user} {username} {server} {count} {created} {joined}
function fill(tpl, member) {
  const ts = (ms) => (ms ? `<t:${Math.floor(ms / 1000)}:R>` : 'un moment');
  return tpl
    .replaceAll('{user}', `<@${member.id}>`)
    .replaceAll('{username}', member.user.username)
    .replaceAll('{server}', member.guild.name)
    .replaceAll('{count}', String(member.guild.memberCount))
    .replaceAll('{created}', ts(member.user.createdTimestamp))
    .replaceAll('{joined}', ts(member.joinedTimestamp));
}

// type : 'welcome' | 'leave'
function build(type, cfg, member) {
  const d = DEFAULTS[type];
  const count = member.guild.memberCount;
  const embed = new EmbedBuilder()
    .setColor(cfg.color ?? d.color)
    .setTitle(fill(cfg.title ?? d.title, member).slice(0, 256))
    .setDescription(fill(cfg.message ?? d.message, member).slice(0, 4000))
    .setThumbnail(member.user.displayAvatarURL({ size: 256 }))
    .setFooter({
      text: type === 'welcome' ? `Membre n°${count}` : `${count} membres restants`,
      iconURL: member.guild.iconURL() ?? undefined,
    })
    .setTimestamp();
  if (cfg.image) embed.setImage(cfg.image);
  return {
    content: type === 'welcome' ? `<@${member.id}>` : undefined,
    embeds: [embed],
    allowedMentions: { users: type === 'welcome' ? [member.id] : [] },
  };
}

// Lit les options communes /arriverconfigurer et /departconfigurer.
// Renvoie { error } ou { patch } (uniquement les champs fournis).
function readOptions(options) {
  const patch = {};
  const titre = options.getString('titre');
  if (titre) patch.title = titre.replaceAll('\\n', '\n');
  const message = options.getString('message');
  if (message) patch.message = message.replaceAll('\\n', '\n');
  const couleur = options.getString('couleur');
  if (couleur) {
    if (!/^#?[0-9a-f]{6}$/i.test(couleur)) return { error: 'Couleur invalide (ex : #5865F2).' };
    patch.color = parseInt(couleur.replace('#', ''), 16);
  }
  const image = options.getString('image');
  if (image) {
    if (image.toLowerCase() === 'aucune') patch.image = null;
    else if (/^https?:\/\/\S+$/i.test(image)) patch.image = image;
    else return { error: 'Image invalide : donne un lien https:// (ou écris `aucune` pour l\'enlever).' };
  }
  return { patch };
}

const VARS = '`{user}` `{username}` `{server}` `{count}` `{created}` `{joined}`';

module.exports = { build, fill, readOptions, VARS };
