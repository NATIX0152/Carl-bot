// Carte d'arrivée / de départ : la bannière choisie sert de FOND, avec l'avatar et le texte dessus.
const fs = require('fs');
const path = require('path');
const { createCanvas, loadImage, GlobalFonts } = require('@napi-rs/canvas');

const W = 1000;
const H = 360;
const FONT = 'CardFont';
const BANNER_DIR = path.join(__dirname, '..', '..', 'data', 'banners');

try {
  GlobalFonts.registerFromPath(path.join(__dirname, '..', '..', 'assets', 'fonts', 'DejaVuSans-Bold.ttf'), FONT);
} catch (e) {
  console.error('[card] police introuvable :', e.message);
}

const bannerPath = (guildId, type) => path.join(BANNER_DIR, `${guildId}-${type}.jpg`);

// Dessine une image en "cover" (remplit toute la zone, rogne ce qui dépasse)
function drawCover(ctx, img, w, h) {
  const s = Math.max(w / img.width, h / img.height);
  const dw = img.width * s;
  const dh = img.height * s;
  ctx.drawImage(img, (w - dw) / 2, (h - dh) / 2, dw, dh);
}

// Télécharge une image (lien https), la recadre en 1000x360 et la sauvegarde pour ce serveur.
async function saveBanner(guildId, type, url) {
  if (!/^https:\/\/\S+$/i.test(url)) throw new Error('Le lien doit commencer par https://');
  const res = await fetch(url, { signal: AbortSignal.timeout(15_000) });
  if (!res.ok) throw new Error(`Téléchargement impossible (code ${res.status})`);
  const buf = Buffer.from(await res.arrayBuffer());
  if (buf.length > 10 * 1024 * 1024) throw new Error('Image trop lourde (10 Mo max)');
  let img;
  try { img = await loadImage(buf); } catch { throw new Error('Ce fichier n\'est pas une image valide (PNG, JPG, WEBP, GIF)'); }
  const canvas = createCanvas(W, H);
  drawCover(canvas.getContext('2d'), img, W, H);
  fs.mkdirSync(BANNER_DIR, { recursive: true });
  fs.writeFileSync(bannerPath(guildId, type), canvas.toBuffer('image/jpeg', 92));
}

function removeBanner(guildId, type) {
  fs.rmSync(bannerPath(guildId, type), { force: true });
}

const hasBanner = (guildId, type) => fs.existsSync(bannerPath(guildId, type));

function fit(ctx, text, maxWidth, size) {
  let s = size;
  do { ctx.font = `${s}px ${FONT}`; s -= 2; } while (ctx.measureText(text).width > maxWidth && s > 18);
}

// Texte avec ombre pour rester lisible sur n'importe quel fond
function shadowText(ctx, text, x, y) {
  ctx.shadowColor = 'rgba(0,0,0,0.85)';
  ctx.shadowBlur = 8;
  ctx.fillText(text, x, y);
  ctx.shadowBlur = 0;
}

async function renderCard(type, member) {
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');

  // Fond = bannière du serveur
  ctx.drawImage(await loadImage(bannerPath(member.guild.id, type)), 0, 0, W, H);
  // Voile sombre pour la lisibilité
  const grad = ctx.createLinearGradient(0, 0, 0, H);
  grad.addColorStop(0, 'rgba(0,0,0,0.25)');
  grad.addColorStop(1, 'rgba(0,0,0,0.65)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, W, H);

  // Avatar rond au centre
  const cx = W / 2;
  const r = 85;
  const cy = 118;
  ctx.save();
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.closePath();
  ctx.clip();
  try {
    const res = await fetch(member.user.displayAvatarURL({ extension: 'png', size: 256 }), { signal: AbortSignal.timeout(8000) });
    ctx.drawImage(await loadImage(Buffer.from(await res.arrayBuffer())), cx - r, cy - r, r * 2, r * 2);
  } catch {
    ctx.fillStyle = '#5865f2';
    ctx.fillRect(cx - r, cy - r, r * 2, r * 2);
  }
  ctx.restore();
  ctx.beginPath();
  ctx.arc(cx, cy, r + 3, 0, Math.PI * 2);
  ctx.lineWidth = 7;
  ctx.strokeStyle = '#ffffff';
  ctx.stroke();

  // Textes
  const count = member.guild.memberCount;
  ctx.textAlign = 'center';
  ctx.fillStyle = '#ffffff';
  fit(ctx, type === 'welcome' ? 'BIENVENUE' : 'AU REVOIR', 900, 46);
  shadowText(ctx, type === 'welcome' ? 'BIENVENUE' : 'AU REVOIR', cx, 260);
  fit(ctx, member.user.username, 900, 36);
  shadowText(ctx, member.user.username, cx, 303);
  ctx.fillStyle = '#e0e0e0';
  const sub = type === 'welcome' ? `Membre n°${count}` : `${count} membres restants`;
  fit(ctx, sub, 900, 24);
  shadowText(ctx, sub, cx, 337);

  return canvas.toBuffer('image/png');
}

module.exports = { renderCard, saveBanner, removeBanner, hasBanner };
