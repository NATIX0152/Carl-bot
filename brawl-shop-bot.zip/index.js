// Point d'entrée de secours : marche même si l'hébergeur démarre "index.js" au lieu de "src/index.js"
require('./src/index.js');
